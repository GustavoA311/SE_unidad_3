# Analisis-lexico-sintactico-Python
Analizador de léxico y sintáctico usando PLY ( Implementación de herramienta de análisis Lex-Yacc para Python)

![Captura](vista/captura.png)

Desarrollando en el curso de compiladores QI2017
